import os
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

# Start menyu
start_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
start_keyboard.add(KeyboardButton("📊 Mening hisobim"))
start_keyboard.add(KeyboardButton("📤 Screenshot yuborish"))
start_keyboard.add(KeyboardButton("📱 Telefon raqam yuborish", request_contact=True))

@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    await message.answer("Salom! Men ovoz berish botman 🚀", reply_markup=start_keyboard)

@dp.message_handler(lambda msg: msg.text == "📊 Mening hisobim")
async def my_account(message: types.Message):
    await message.answer("Sizning hisobingiz: 0 ta ovoz.")

@dp.message_handler(content_types=["photo"])
async def photo_handler(message: types.Message):
    await message.photo[-1].download(destination_file=f"screenshots/{message.from_user.id}.jpg")
    await message.answer("✅ Screenshot qabul qilindi!")
    await bot.send_message(ADMIN_ID, f"📷 {message.from_user.full_name} screenshot yubordi.")

@dp.message_handler(content_types=["contact"])
async def contact_handler(message: types.Message):
    phone = message.contact.phone_number
    await message.answer(f"✅ Telefon raqamingiz qabul qilindi: {phone}")
    await bot.send_message(ADMIN_ID, f"📱 {message.from_user.full_name} telefon yubordi: {phone}")

if __name__ == "__main__":
    from aiogram import executor
    executor.start_polling(dp, skip_updates=True)
